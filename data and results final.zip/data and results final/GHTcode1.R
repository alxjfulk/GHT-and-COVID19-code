#####MATCH GOOGLE HEALTH TRENDS - EPIDEMIOLOGICAL DATA######

# --------------------------------------------------------
#'  Author: Daniel Romero-Alvarez, Alex Fulk, Qays Abu-Saymeh
#                
#'  Script to:
#'  Match google health trends data with weekly case incidence for any state
#'  Example starts with Brazilian data 

# --------------------------------------------------------


#####LIBRARIES#####
library (plyr) #transforming lists on dataframes
library(datetimeutils) #changing_dates
library(ggrepel) #for fig 1
library( ggplot2 ) #for fig 1
library(rgdal)
library(lmtest) #test for heteroscedasticity 
#####IMPORTANT DETAILS######

#' This code needs google health trends data and also 
#' epidemiological data that matches the google health trends week 
#' data division. You can follow the code weekly_BR_cases in order 
#' to arrange databases. 
#' All the google health trends data has been adquired and added for 
#' countries and states in the corresponding dropbox folder. 
#' 
#' 
#' We need to collect the following data: 
#' - Number of useful terms. 
#' - Adjusted R squared per model.  
#' - Plot of covid-19 incidence + regression line 
#' - Date of first case per model... 
#' 

####PRE-PROCESSING######

#FOR TRANSFORMING DAILY CASE DATA TO WEEKLY CASE DATA
#load daily case and GHT data for an individual country
BR = read.csv ('C:/Users/a426f262/Downloads/GHT-and-COVID19-code-main/GHT-and-COVID19-code-main/data and results/data and results/daily_data/Algeria.csv', header = T)
AL1 = read.csv ('C:/Users/a426f262/Downloads/GHT-and-COVID19-code-main/GHT-and-COVID19-code-main/data and results/data and results/GHT data/DZ_DZ.csv')

#save relevent information into a dataframe
BR1 <- data.frame('date' = BR$date,
                  'Cumulative Cases' = BR$Cumulative.Cases,
                  'New Cases' = BR$New.Cases,
                  'Cumulative Death' = BR$Cumulative.Death,
                  'New Death' = BR$New.Death)
pop1 <- data.frame('pop' = BR$pop)

#fix the dates so that R can work with them
BR1$date = gsub (BR1$date, pattern ='/',replacement = '-')
BR1$date = as.Date(BR1$date,format="%m-%d-%Y")

BR1$date = as.Date(BR1$date)

#subset the data to the appropriate timeframe 
BR1 = BR1[BR1$date > '2020-02-01'& BR1$date < '2021-09-26',] 
tail(BR1)
#subset by important columns: 
names (BR1)
BR1 = BR1[,c(1, 2, 3, 4, 5)]



#change name of BR1 column name
colnames(BR1)[colnames(BR1) == "date"] <- "data"

#Create a new dataframe based on weekly cumulative cases

BR_comp = list() #open empty list 


vct= seq (1,length(BR1$data), 7)

for (i in seq (1,length(BR1$data), 7)){ #loop each 7 days till the end of the DF
  rr = BR1[(BR1$data > BR1$data[i] & BR1$data <= BR1$data[i+7]),] #subset DF above first row 
  cs = colSums(rr[,2:ncol(rr)]) #sum cases for this subset
  df =  t(as.data.frame (cs)) #transform in dataframe and transpose
  cs2 = cbind (data = as.character(BR1$data[i+7]), df) #add the name to the dataframe
  BR_comp[[length(BR_comp)+1]] = cs2 #add to the list 
}



BR_rw = ldply(BR_comp, data.frame) #transform list to dataframe
BR_week = rbind (BR1[1,1:ncol(BR1)], BR_rw) #add first row previously ignored 
BR_week = BR_week[-(length(BR_week$data)),] #eliminate last row with NA if needed
BR_week$data = as.Date(BR_week$data) #define first column as class dates 
#add population column, you will need to look this up for each country
BR_week$pop=rep(pop1[1,"pop"],length(BR_week$New.Cases))

#write the file with the weekly case data and population column added
#write.csv (BR_week, '/Algeria.csv', row.names = F)

#####formatting GHT data#####
#load the country search data by its 2-letter alpha 2 code
AL1$date = as.Date(AL1$date) #convert columns to actual dates
AL1 = AL1[AL1$date > '2020-02-01'& AL1$date < '2021-09-26',] #subset to the approporiate timeframe

#usful words: 
AL2 = AL1[,colSums(AL1 !=0) >0] #this selects those columns that have information 
names (AL2)

AL2_comp = list() #open empty list 


vct= seq (1,length(AL2$date), 7)

for (i in seq (1,length(AL2$date), 7)){ #loop each 7 days till the end of the DF
  rr = AL2[(AL2$date > AL2$date[i] & AL2$date <= AL2$date[i+7]),] #subset DF above first row 
  cs = colSums(rr[,2:ncol(rr)]) #sum cases for this subset
  df =  t(as.data.frame (cs)) #transform in dataframe and transpose
  cs2 = cbind (data = as.character(AL2$date[i+7]), df) #add the name to the dataframe
  AL2_comp[[length(AL2_comp)+1]] = cs2 #add to the list 
}
#change name of AL2 column name
colnames(AL2)[colnames(AL2) == "date"] <- "data"


AL2_rw = ldply(AL2_comp, data.frame) #transform list to dataframe
AL2_week = rbind (AL2[1,1:ncol(AL2)], AL2_rw) #add first row previously ignored 
AL2_week = AL2_week[-(length(AL2_week$data)),] #eliminate last row with NA if needed
AL2_week$data = as.Date(AL2_week$data) #define first column as class dates 

AL2_diff = data.frame(diff(data.matrix(AL2_week[,2:length(AL2_week)])))
AL2_week = data.frame(data.matrix(AL2_week))
#important words: 

def_tms = AL2_rw[,2:length(AL2_rw)] #only terms dataset
def_tms_diff = AL2_diff

#select words that we would like to analyze. if a word is missing, simply comment out the word.
def_tms1 <- data.frame('COVID19' = def_tms$COVID19, 
                       'coronavirus' = def_tms$coronavirus,
                       'coronavirus symptoms' = def_tms$coronavirus.symptoms, 
                       'pandemic' = def_tms$pandemic)
def_tms1_diff <- data.frame('COVID19' = def_tms_diff$COVID19, 
                            'coronavirus' = def_tms_diff$coronavirus,
                            'coronavirus symptoms' = def_tms_diff$coronavirus.symptoms,
                            'pandemic' = def_tms_diff$pandemic)
#average_tm = apply(def_tms1, 2, FUN = mean)

median_tm = apply(def_tms1, 2, FUN= median) #obtaining a vector with the medians
bp = names(median_tm)
####MULTIPLE LINEAR REGRESSION ANALYSIS WITH WEEKLY CASES AS DEPENDENT VARIABLE AND GHT SEARCH DATA AS INDEPENDENT VARIABLE####

#this is used to do the regression analysis and create the figure corresponding to the country that you are doing the regression for 

#reading data already processed by week
AL_br1 = BR_week
nrow(data.frame(AL2_rw$COVID19))
ALdiff = data.frame(matrix(NA, nrow = nrow(AL_br1)-1))
# # #Objects with information of the week of the first case 
# #load DAILY data file
# ot = read.csv ('/Algeria.csv')
# ot <- data.frame('date' = ot$date,
#                  'Cumulative Cases' = ot$Cumulative.Cases,
#                  'New Cases' = ot$New.Cases)
# ot$date = gsub (ot$date, pattern ='/',replacement = '-')
# ot$date = as.Date(ot$date,format="%m-%d-%Y")
# ot$date = as.Date(ot$date) #defining as dates
# 
# f_c = ot$New.Cases[ot$New.Cases>0][1] #number of first cases in the original state database
# f_c1 = AL_br1$New.Cases[AL_br1$New.Cases>0][1] #number of first cases in the weekly state database
# 
# ff_1 = as.Date(ot[which(ot$New.Cases == f_c)[1], 1]) #obtain the date through index and subsetting table 1
# ff_2 = as.Date(AL_br1[which(AL_br1$New.Cases == f_c1)[1], 1]) #obtain the date through index and subsetting table 2

#calculate incidence per state adding a new column to the datafram: inci: 
AL_br1$inci = as.numeric(AL_br1$New.Cases)/AL_br1$pop
acf(AL_br1$inci)
ALdiff$inci = data.frame(diff(AL_br1$inci))
acf(ALdiff$inci)
#regression using all available terms per state: 
median_tm = apply(def_tms1, 2, FUN= median) #obtaining a vector with the medians
median_tm_diff = apply(def_tms1_diff, 2, FUN= median)
bp = names(median_tm)#names for boxplot
bp_diff = names(median_tm_diff)

bt = paste('AL2_week', '$', bp , sep = '') #VECTOR SUBSETTING THE COLUMNS ACCORDING TO THE MENTIONED WORDS
bt_diff = paste('AL2_diff', '$', bp_diff , sep = '')

AL1_form1 = formula(c(paste ('AL_br1$inci~'), 
                      paste(bt, collapse = ' + '))) #formula for the regression

AL1_model = lm(AL1_form1) #regression

AL1_rq = summary(AL1_model)$adj.r.squared #collect adj. r squared


AL1_form1_diff = formula(c(paste ('as.matrix(ALdiff$inci)~'), 
                           paste(as.matrix(bt_diff), collapse = ' + '))) #formula for the regression

AL1_model_diff = lm(AL1_form1_diff) #weighted regression

gqtest(AL1_model_diff, order.by = ~AL2_diff$coronavirus + AL2_diff$COVID19 + AL2_diff$coronavirus.symptoms + AL2_diff$pandemic, fraction = 20)
bptest(AL1_model_diff)

wt <- 1 / abs(lm(abs(AL1_model_diff$residuals) ~ AL1_model_diff$fitted.values)$fitted.values)

AL1_model_diff_wt <- lm(AL1_form1_diff, weights=wt)

AL1_rq_diff = summary(AL1_model_diff_wt)$adj.r.squared


#FOR HIGH QUALITY FIGURE OUTPUT

tiff("Algeria_cases.tiff", units="in", width=6, height=5, res=300)

#plot incidence
plot (AL_br1$inci, main = bquote(AF ~ - ~ Algeria ~ Adjusted ~ R^2 == .(round(AL1_rq,4))),
      ylab = 'Weekly case incidence', xlab = '', xaxt ='n',
      type = 'l', pch = 19, cex = 0.3, cex.axis = 1.3, cex.main = 1.5, cex.lab = 1.4)
#regression line 
lines (predict (AL1_model), col = 'blue', type ='b', pch = 19, cex = 0.3) 
#x-axis

axis (1, at=c(1,28,59,89,120,150,181,212,242,273,303,334,365,393,424,454,485,515),
      labels = c('Feb.', 'Mar.', 'Apr.', 'May', 'Jun.','Jul.','Aug.','Sep.','Oct.','Nov.','Dec.','Jan.',
                 'Feb.', 'Mar.', 'Apr.', 'May', 'Jun.','Jul.'), cex.axis = 1, las=2)

# text (30, quantile(AL_br1$inci, 0.95),
#       labels = paste ('First case = ', '\n\ ', ff_1, sep = ''), 
#       cex = 0.8, pos = '3', col= 'red', srt = 0)

#adding legend
legend('topleft', legend=c("Observed", "Model"),
       col=c("black", 'blue'), pch = c(NA,19,NA), lty = c(1, 1, 1), cex=0.8) 
dev.off()

tiff("Algeria_diff_cases.tiff", units="in", width=6, height=5, res=300)

#plot incidence
plot (as.numeric(unlist(ALdiff$inci)), main = bquote(AF ~ - ~ Algeria ~ Adjusted ~ R^2 == .(round(AL1_rq_diff,4))),
      ylab = 'Differenced Weekly case incidence', xlab = '', xaxt ='n',
      type = 'l', pch = 19, cex = 0.3, cex.axis = 1.3, cex.main = 1.5, cex.lab = 1.4)
#regression line 
lines (predict (AL1_model_diff_wt), col = 'blue', type ='b', pch = 19, cex = 0.3) 
#x-axis

# axis (1, at=c(1,28,59,89,120,150,181,212,242,273,303,334,365,393,424,454,485,515),
#       labels = c('Feb.', 'Mar.', 'Apr.', 'May', 'Jun.','Jul.','Aug.','Sep.','Oct.','Nov.','Dec.','Jan.',
#                  'Feb.', 'Mar.', 'Apr.', 'May', 'Jun.','Jul.'), cex.axis = 1, las=2)

# text (30, quantile(AL_br1$inci, 0.95),
#       labels = paste ('First case = ', '\n\ ', ff_1, sep = ''), 
#       cex = 0.8, pos = '3', col= 'red', srt = 0)

#adding legend
legend('topleft', legend=c("Observed", "Model"),
       col=c("black", 'blue'), pch = c(NA,19,NA), lty = c(1, 1, 1), cex=0.8) 
dev.off()


summary(AL1_model)$adj.r.squared
summary(AL1_model_diff_wt)$adj.r.squared


#####VOLATILITY INDEX######
#code used to create the volatility index indicator for each country

#Example with Zimbabwe

#read weekly data for an individual country
alg = read.csv ('/Zimbabwe.csv')

#I AM USING THE CASES FOR THIS EXAMPLE BUT YOU NEED TO PUT HERE THE INCIDENCE
alg$inci = alg$New.Cases/alg$pop


#normalization of the data
alg_mean = mean (alg$inci) #calculate the mean
alg_sd = sd(alg$inci) #calculate the standard deviation 

alg_norm = (alg$inci - alg_mean)/alg_sd #normalization for Algeria

#comparing histograms
dev.new()
par(mfrow = c(2,1))
hist(alg_norm) #normalized data
hist(alg$inci) #original data 

length (alg_norm) #total amount of rows 

#volatility index loop 
do2 = list () #empty list 
for (d in 1:26){ #loop to total-1 number of rows 
  t1 = abs(alg_norm[d]-alg_norm[d+1]) #absolute difference between 2 consecutive weeks 
  do2[[length(do2)+1]] = t1 #add to the list
}

do3 = unlist (do2) #total of 25 observations
alg_v = mean (do3) #calculate the mean which is the volatility score for that country

plot (alg_norm, main = paste ('Volatility = ', round (alg_v,3), sep = ''), type = 'l') #low volatility


# Collect the volatility score for each country and then create a regression in the form: 
# 
# r_squares ~ volatility scores
# 
# Record the new r_square

######INDICATOR REGRESSION ANALYSES#######

#FOR THE LINEAR  REGRESSION ANALYSES USING ADJ R2 AS THE DEPENDENT VARIABLE AND A SINGLE INDICATOR AS THE INDEPENDENT VARIABLE
#load data
indices12 = read.csv('C:/Users/a426f262/Downloads/GHT-and-COVID19-code-main/GHT-and-COVID19-code-main/data and results/data and results/results_and_WB_data/ResultsandWBdata2.csv')

indicesdf = data.frame(indices12)

#I wrote out each index, but there's probably an easier way to do this just FYI. As you can see, 
#you just put each column into the log function in R and it spits out the log-transformed data in 
#the same format as your previous data frame
indices12 <- data.frame('Country' = indices12$Country,
                        'Adjusted.R2' = indices12$Adjusted.R2,
                        'Access.to.electricity' = indices12$Access.to.electricity,
                        'Avg.weekly.cases' = indices12$Avg.weekly.cases,
                        'Community.health.workers' = indices12$Community.health.workers,
                        'Cumulative.deaths' = indices12$Cumulative.deaths,
                        'Current.health.expenditure' = indices12$Current.health.expenditure,
                        'Fixed.broadband.subscriptions' = indices12$Fixed.broadband.subscriptions,
                        'Fixed.broadband.subscriptions.per' = indices12$Fixed.broadband.subscriptions.per,
                        'Fixed.telephone.subscriptions' = indices12$Fixed.telephone.subscriptions,
                        'Fixed.telephone.subscriptions.per' = indices12$Fixed.telephone.subscriptions.per,
                        'GDP' = indices12$GDP,
                        'Hospital.beds' = indices12$Hospital.beds,
                        'Individuals.using.the.Internet' = indices12$Individuals.using.the.Internet,
                        'Life.expectancy.at.birth' = indices12$Life.expectancy.at.birth,
                        'Literacy.rate.adult.total' = indices12$Literacy.rate.adult.total,
                        'Mobile.cellular.subscriptions' = indices12$Mobile.cellular.subscriptions,
                        'Mobile.cellular.subscriptions.per' = indices12$Mobile.cellular.subscriptions.per,
                        'People.with.basic.handwashing.facilities' = indices12$People.with.basic.handwashing.facilities,
                        'Physicians' = indices12$Physicians,
                        'Population.density' = indices12$Population.density,
                        'Population' = indices12$Population,
                        'Prevalence.of.severe.food.insecurity.in.the.population' = indices12$Prevalence.of.severe.food.insecurity.in.the.population,
                        'Smoking.prevalence' = indices12$Smoking.prevalence,
                        'Urban.population' = indices12$Urban.population,
                        'Urban.population.' = indices12$Urban.population.percent.of.pop,
                        'GDP.per.capita' = indices12$GDP.per.capita,
                        'Nurses.and.midwives' = indices12$Nurses.and.midwives,
                        'People.using.at.least.basic.drinking.water.services' = indices12$People.using.at.least.basic.drinking.water.services,
                        'People.using.at.least.basic.sanitation.services' = indices12$People.using.at.least.basic.sanitation.services,
                        'People.using.safely.managed.drinking.water.services' = indices12$People.using.safely.managed.drinking.water.services,
                        'People.using.safely.managed.sanitation.services' = indices12$People.using.safely.managed.sanitation.services,
                        'Risk.of.catastrophic.expenditure.for.surgical.care' = indices12$Risk.of.catastrophic.expenditure.for.surgical.care,
                        'Risk.of.impoverishing.expenditure.for.surgical.care' = indices12$Risk.of.impoverishing.expenditure.for.surgical.care,
                        'Secure.Internet.servers' = indices12$Secure.Internet.servers,
                        'Prevalence.of.moderate.or.severe.food.insecurity.in.the.population' = indices12$Prevalence.of.moderate.or.severe.food.insecurity.in.the.population,
                        'Prevalence.of.HIV' = indices12$Prevalence.of.HIV,
                        'Volatility' = indices12$Volatility,
                        'Adjusted.R2.diff' = indices12$Adjusted.R2.diff)

indices12_log <- data.frame('Country' = indices12$Country,
                            'Adjusted.R2' = indices12$Adjusted.R2,
                            'Access.to.electricity' = log(indices12$Access.to.electricity),
                            'Avg.weekly.cases' = log(indices12$Avg.weekly.cases),
                            'Community.health.workers' = log(indices12$Community.health.workers),
                            'Cumulative.deaths' = log(indices12$Cumulative.deaths),
                            'Current.health.expenditure' = log(indices12$Current.health.expenditure),
                            'Fixed.broadband.subscriptions' = log(indices12$Fixed.broadband.subscriptions),
                            'Fixed.broadband.subscriptions.per' = log(indices12$Fixed.broadband.subscriptions.per),
                            'Fixed.telephone.subscriptions' = log(indices12$Fixed.telephone.subscriptions),
                            'Fixed.telephone.subscriptions.per' = log(indices12$Fixed.telephone.subscriptions.per),
                            'GDP' = log(indices12$GDP),
                            'Hospital.beds' = log(indices12$Hospital.beds),
                            'Individuals.using.the.Internet' = log(indices12$Individuals.using.the.Internet),
                            'Life.expectancy.at.birth' = log(indices12$Life.expectancy.at.birth),
                            'Literacy.rate.adult.total' = log(indices12$Literacy.rate.adult.total),
                            'Mobile.cellular.subscriptions' = log(indices12$Mobile.cellular.subscriptions),
                            'Mobile.cellular.subscriptions.per' = log(indices12$Mobile.cellular.subscriptions.per),
                            'People.with.basic.handwashing.facilities' = log(indices12$People.with.basic.handwashing.facilities),
                            'Physicians' = log(indices12$Physicians),
                            'Population.density' = log(indices12$Population.density),
                            'Population' = log(indices12$Population),
                            'Prevalence.of.severe.food.insecurity.in.the.population' = log(indices12$Prevalence.of.severe.food.insecurity.in.the.population),
                            'Smoking.prevalence' = log(indices12$Smoking.prevalence),
                            'Urban.population' = log(indices12$Urban.population),
                            'Urban.population.' = log(indices12$Urban.population.),
                            'GDP.per.capita' = log(indices12$GDP.per.capita),
                            'Nurses.and.midwives' = log(indices12$Nurses.and.midwives),
                            'People.using.at.least.basic.drinking.water.services' = log(indices12$People.using.at.least.basic.drinking.water.services),
                            'People.using.at.least.basic.sanitation.services' = log(indices12$People.using.at.least.basic.sanitation.services),
                            'People.using.safely.managed.drinking.water.services' = log(indices12$People.using.safely.managed.drinking.water.services),
                            'People.using.safely.managed.sanitation.services' = log(indices12$People.using.safely.managed.sanitation.services),
                            'Risk.of.catastrophic.expenditure.for.surgical.care' = log(indices12$Risk.of.catastrophic.expenditure.for.surgical.care),
                            'Risk.of.impoverishing.expenditure.for.surgical.care' = log(indices12$Risk.of.impoverishing.expenditure.for.surgical.care),
                            'Secure.Internet.servers' = log(indices12$Secure.Internet.servers),
                            'Prevalence.of.moderate.or.severe.food.insecurity.in.the.population' = log(indices12$Prevalence.of.moderate.or.severe.food.insecurity.in.the.population),
                            'Prevalence.of.HIV' = log(indices12$Prevalence.of.HIV),
                            'Volatility' = log(indices12$Volatility),
                            'Adjusted.R2.diff' = indices12$Adjusted.R2.diff)

names(indices12_log)

#for this section, I did one indicator and its log-adjusted counterpart at a time
#simply select the indicator that you wish to use (the names function above will help with this):
linearpredictor = indices12[,c(1:39)]
linearpredictor1 = indices12_log[,c(1:39)]

predictor1 = data.frame(indices12$Access.to.electricity)
logpredictor1 = data.frame(log(indices12$Access.to.electricity))
#remove NAs
linearpredictor = data.frame(linearpredictor[rowSums(is.na(predictor1)) < 1,])
linearpredictor1 = data.frame(linearpredictor1[rowSums(is.na(logpredictor1)) < 1,])

#then you use the new data frame in the linear regression model 

linearmodel = lm(linearpredictor$'Adjusted.R2' ~
              linearpredictor$'Prevalence.of.moderate.or.severe.food.insecurity.in.the.population')
linearmodel1 = lm(linearpredictor1$'Adjusted.R2' ~
              linearpredictor1$'Prevalence.of.moderate.or.severe.food.insecurity.in.the.population')
linearmodeldiff = lm(linearpredictor$'Adjusted.R2.diff' ~
                   linearpredictor$'Access.to.electricity')
linearmodel1diff = lm(linearpredictor1$'Adjusted.R2.diff' ~
                    linearpredictor1$'Access.to.electricity')
#and collect the r2 value along with any other relevant information that you like:
summary(linearmodel)
summary(linearmodel1)
summary(linearmodeldiff)
summary(linearmodel1diff)
# FOR THE MULTIPLE LINEAR REGRESSION W INDICATORS
#first we define the full model with all of the indicators that will be used:

#model with regular data: 
predictor1 = indices12[,c(1:39)]

model = lm(predictor1$'Adjusted.R2.diff' ~
            predictor1$'Access.to.electricity'+
            predictor1$'Avg.weekly.cases'+
            predictor1$'Cumulative.deaths'+
            predictor1$'Current.health.expenditure'+
            predictor1$'GDP'+
            predictor1$'Individuals.using.the.Internet'+
            predictor1$'Life.expectancy.at.birth'+
            predictor1$'Mobile.cellular.subscriptions'+
            predictor1$'Mobile.cellular.subscriptions.per'+
            predictor1$'Population'+
            predictor1$'Urban.population'+
            predictor1$'Urban.population.'+
            predictor1$'GDP.per.capita'+
            predictor1$'People.using.at.least.basic.drinking.water.services'+
            predictor1$'People.using.at.least.basic.sanitation.services'+
            predictor1$'Secure.Internet.servers'+
            predictor1$'Volatility')

#then place the model into the 'step' function to obtain the best combination of indicators based on AIC score
sws = step (model,direction = 'both')
summary(sws)
#log-adjusted version:
predictor2 = indices12_log[,c(1:39)]
model1 = lm(predictor2$'Adjusted.R2.diff' ~
             predictor2$'Access.to.electricity'+
             predictor2$'Avg.weekly.cases'+
             predictor2$'Cumulative.deaths'+
             predictor2$'Current.health.expenditure'+
             predictor2$'GDP'+
             predictor2$'Individuals.using.the.Internet'+
             predictor2$'Life.expectancy.at.birth'+
             predictor2$'Mobile.cellular.subscriptions'+
             predictor2$'Mobile.cellular.subscriptions.per'+
             predictor2$'Population'+
             predictor2$'Urban.population'+
             predictor2$'Urban.population.'+
             predictor2$'GDP.per.capita'+
             predictor2$'People.using.at.least.basic.drinking.water.services'+
             predictor2$'People.using.at.least.basic.sanitation.services'+
             predictor2$'Secure.Internet.servers'+
             predictor2$'Volatility')
#then place the model into the 'step' function to obtain the best combination of indicators based on AIC score
sws1 = step (model1,direction = 'both')
summary(sws1)

#FOR THE LASSO REGRESSION W INDICATORS
#extract dependent variable
y <- indices12$Adjusted.R2
ydiff <- indices12$Adjusted.R2.diff
#extract independent variables
x <- data.matrix(indices12[,c(3,4,6,7,12,14,15,17,18,22,25,26,27,29,30,35,38)])

library(glmnet)
#perform k-fold cross-validation to find optimal lambda value
cv_model_L <- cv.glmnet(x, ydiff, alpha = 1)

#find optimal lambda value that minimizes test MSE
best_lambda_L <- cv_model_L$lambda.min
#produce plot of test MSE by lambda value
plot(cv_model_L) 
#find coefficients of best model
best_model_L <- glmnet(x, ydiff, alpha = 1, lambda = best_lambda_L)
coef(best_model_L)

predictor_L = indices12[,c(1:39)]

model_L = lm(predictor_L$'Adjusted.R2.diff' ~
               predictor_L$'Volatility' + predictor_L$'Access.to.electricity')
summary(model_L)


#extract dependent variable
y1 <- indices12_log$Adjusted.R2
y1diff <- indices12_log$Adjusted.R2.diff
#extract independent variables
x1 <- data.matrix(indices12_log[,c(3,4,6,7,12,14,15,17,18,22,25,26,27,29,30,35,38)])

#perform k-fold cross-validation to find optimal lambda value
cv_model_L1 <- cv.glmnet(x1, y1diff, alpha = 1)

#find optimal lambda value that minimizes test MSE
best_lambda_L1 <- cv_model_L1$lambda.min
#produce plot of test MSE by lambda value
plot(cv_model_L1) 
#find coefficients of best model
best_model_L1 <- glmnet(x1, y1diff, alpha = 1, lambda = best_lambda_L1)
coef(best_model_L1)

predictor_L1 = indices12_log[,c(1:39)]

model_L1 = lm(predictor_L1$'Adjusted.R2.diff' ~
                predictor_L1$'Volatility' + predictor_L1$'Avg.weekly.cases')
summary(model_L1)


########FIGURE 1############
fc = read.csv('/dofc.csv')
fc1 <- data.frame(Country = fc$Country,
                  First = fc$Day.of.First.Case)
fc1$First <- as.Date(fc1$First, "%m/%d/%Y")
colnames(fc1) = c('Country', 'Day.of.the.First.Case')

p <- ggplot( fc1, aes(x=Country, y=Day.of.the.First.Case) ) + geom_point() + 
  scale_y_date( date_labels = "%b %d", date_breaks = "1 week") +
  theme(axis.text.x=element_blank()) +
  labs( y="Date", x="Country")
p + geom_text_repel(aes(label=fc$ID), size=2) + theme(legend.position = "None")   # text

plot1 = p + geom_label_repel(aes(label=fc$ID), size=2)  + theme(legend.position = "None")   # label
ggsave('dofcgraph1.tiff', plot=plot1, width=6, height=5,units='in', dpi=300)



######SHAPEFILE FOR MAPS (FIGURE 2)#####

#you will need to generate these files if you don't download them form the github repository:

#avg weekly deaths for the four time periods
#load DAILY case data
list1 = list.files('C:/Users/a426f262/Downloads/GHT-and-COVID19-code-main/GHT-and-COVID19-code-main/data and results/data and results/daily_data', full.names = T)
# #creates empty dataframe
df = list()
#AL = read.csv('C:/Users/a426f262/Downloads/GHT-and-COVID19-code-main/GHT-and-COVID19-code-main/data and results/data and results/daily_data/Zimbabwe.csv', header = T)
for (i in list1){

  AL = read.csv (i)
  AL$caseinci = (as.numeric(AL$New.Cases)/AL$pop)*100000
  AL$deathinci = (as.numeric(AL$New.Death)/AL$pop)*100000
  obj1 = mean(AL[12:161,8])
  obj2 = mean(AL[162:314,8])
  obj3 = mean(AL[315:465,8])
  obj4 = mean(AL[466:613,8])
  cl = c(obj1,obj2,obj3,obj4)
  df[[length(df)+1]] = cl
}

finalobj = t(data.frame(df))
finalobj = data.frame(finalobj)

# #change column names for the four time periods
names(finalobj)[names(finalobj) == "X1"] <- "Feb.2.to.June.30"
names(finalobj)[names(finalobj) == "X2"] <- "July.1.to.Nov.30"
names(finalobj)[names(finalobj) == "X3"] <- "Dec.1.to.April.30"
names(finalobj)[names(finalobj) == "X4"] <- "May.1.to.Sep.25"
# View(finalobj)
write.csv (finalobj, 'C:/Users/a426f262/Downloads/GHT-and-COVID19-code-main/GHT-and-COVID19-code-main/data and results/data and results/avg_cases_and_death/avgdeath_1-08-2022.csv', row.names = F )


#HERE IS WHERE THE CODE RELEVENT TO CREATING THE SHAPE FILE BEGINS:
#reading databases (with official country ID and corrected by population (incidence), top line is case data, bottom is death data)
cas = read.csv ('C:/Users/a426f262/Downloads/GHT-and-COVID19-code-main/GHT-and-COVID19-code-main/data and results/data and results/avg_cases_and_death/avgcases_1-08-2022.csv')
cas1 = read.csv ('C:/Users/a426f262/Downloads/GHT-and-COVID19-code-main/GHT-and-COVID19-code-main/data and results/data and results/avg_cases_and_death/avgdeath_1-08-2022.csv')
fc1 = read.csv ('/dofcredo1.csv')

#download the world in countries from: https://www.naturalearthdata.com/downloads/50m-cultural-vectors/

#read the shapefile: 
wrd = readOGR('C:/Users/a426f262/Desktop/New folder/School/Research/Covid19/Africa Country Data/Combined1/shape/afr1.shp')
WGS84 = crs(wrd) #define the projection 
afr1 = wrd
names(wrd@data) #check the name of the columns
unique (wrd@data$CONTINENT) #check the names of the column called CONTIINENT 
unique (wrd@data$NAME)

#add the two missing countries (seychelles and mauritius) and remove the disputed territories (somaliland and western sahara)
coun1 = subset(wrd, NAME == 'Seychelles')
coun2 = subset(wrd, NAME == 'Mauritius')
afr1 = subset (wrd, CONTINENT == 'Africa') #subset by continent name
rbind(afr1,coun1) -> afr1
rbind(afr1,coun2) -> afr1
row.names.remove <- c("193","207")
afr1[!row.names(afr1@data) %in% row.names.remove,] -> afr1
#plot (afr1) #plot the map 
afr1@data$SOV_A3[39] <- 'SSD'#SSD's 3 letter alpha 3 code is incorrect for some reason, this fixes that
names (afr1@data) #review the names of the attribute table of the subset object 


#Now the plan is to make the incidence dataframe match with the spatial polygons dataframe

length (afr1@data$NAME) #checking the length of both dataframes
length(fc1$Country) 

sort(afr1@data$SOV_A3)#sorting the country names by alphabetical order
afr1@data$NAME

or1 = afr1@data$SOV_A3 #defining objects to compare the names, from spatial polygon 
or2 = cas1$ID #defining objects to compare names, from the incidence dataframe
or1 == or2 #comparing both objects...a lot of differences...

#' because of that we decided to MANUALLY add a column in the incidence dataframe
#' with the three letter SOV_A3 column code from the natural earth shapefile
#after checking that everything matches: 
#adding a column from the incidence dataframe in the spatial polygon dataframe for cases: 

afr1@data$FDC = cas$FirstC

afr1@data$SDC = cas$SecondC 

afr1@data$TDC = cas$ThirdC

afr1@data$FoDC = cas$FourthC

afr1@data$Colors = cas$Colors

#for death

afr1@data$FDD = cas1$FirstD

afr1@data$SDD = cas1$SecondD 

afr1@data$TDD = cas1$ThirdD

afr1@data$FoDD = cas1$FourthD

afr1@data$DColors = cas1$Colors

afr1@data$DOFC = fc1$num

afr1@data$DOFC1 = fc1$Num.first.case.1

#write shapefile with the added information: 
writeOGR(afr1, layer= 'afr1', dsn = 'afr123', driver = 'ESRI Shapefile')
#from here, we used QGIS to construct the maps form the adjusted shape file



####FIGURE 3#####

#READ THE BRAZILIAN CODE THAT IS FULLY COMMENTED, THE OTHER ONE IS A REPETITION OF THIS ONE...

#BRAZIL: 
br = read.table ('./alex_qays_res1/GHTBrazilResultsFull.txt', sep = '\t', header = T) #reading the table, 

#' NOTICE: that you should make sure to 
#' eliminate weird characters such as Amapá, 
#' you should eliminate the accent...manually in the file...

head (br) #checking the first 6 lines 

plot (br$Adjusted.R2, ylab = 'Adj. R2', xaxt = 'n', xlab = '', main = 'Brazil', type = 'h') #creating the plot and vertical lines
points (br$Adjusted.R2, pch = 16) #adding the points
axis (1, at= (1:length(br$States)),labels = br$States, las= 2, cex.axis = 0.6) #adding the x axis with the names of the states or countries...
abline (h = 0.6, lty= 2) #adding the threshold line, in this case, 0.6!

#AFRICAN COUNTRIES decreasing R2 plot: 

af = read.csv ('C:/Users/a426f262/Downloads/GHT-and-COVID19-code-main/GHT-and-COVID19-code-main/data and results/data and results/results_and_WB_data/r2plot_weekly_final.csv')
af = data.frame(af)

head (af)

bp_countries = af[,c(1,10,11)] #only countries and r2 values

bp2 = bp_countries[order(bp_countries$Adjusted.R2.Cases.for.plot, decreasing = T),] #ordering the dataframe with the r2 values from high to low 
bp = row.names (bp2$ID) #obtaining the ordered names for the plot
bp2diff = bp_countries[order(bp_countries$Adjusted.R2.Cases.diff.for.plot, decreasing = T),] #ordering the dataframe with the r2 values from high to low 
bpdiff = row.names (bp2diff$ID) #obtaining the ordered names for the plot

y1 <- expression(Adjusted ~ R^2)
x1 <- expression(Adjusted ~ R^2 ~ Results)
y1diff <- expression(Adjusted ~ R^2 ~ Differenced)

tiff("r2plot.tiff", units="in", width=6, height=5, res=300)

par(mfrow=c(2,1))
par(mar=c(2,5,2,1)+.1)
plot (bp2$Adjusted.R2.Cases.for.plot, ylab = y1, xaxt = 'n', xlab = 'African Countries', main = x1, type = 'h')
points (bp2$Adjusted.R2.Cases.for.plot, pch = 16)
axis (1, at= (1:length(bp2$ID)),labels = bp2$ID, las= 2, cex.axis = 0.5)
abline (h = 0.6, lty= 2) 
par(mar=c(4,5,0.4,1)+.1)
plot (bp2diff$Adjusted.R2.Cases.diff.for.plot, ylab = y1diff, xaxt = 'n', xlab = 'African Countries', type = 'h')
points (bp2diff$Adjusted.R2.Cases.diff.for.plot, pch = 16)
axis (1, at= (1:length(bp2diff$ID)),labels = bp2diff$ID, las= 2, cex.axis = 0.5)
abline (h = 0.6, lty= 2) 
dev.off()


##############FIGURE 4###################
#pick out the 6 countries by hand

AL1 = read.csv ('C:/Users/a426f262/Downloads/GHT-and-COVID19-code-main/GHT-and-COVID19-code-main/data and results/data and results/GHT data/DZ_DZ.csv')
AL2 = read.csv ('C:/Users/a426f262/Downloads/GHT-and-COVID19-code-main/GHT-and-COVID19-code-main/data and results/data and results/GHT data/ET_ET.csv')
AL3 = read.csv ('C:/Users/a426f262/Downloads/GHT-and-COVID19-code-main/GHT-and-COVID19-code-main/data and results/data and results/GHT data/KE_KE.csv')
AL4 = read.csv ('C:/Users/a426f262/Downloads/GHT-and-COVID19-code-main/GHT-and-COVID19-code-main/data and results/data and results/GHT data/BF_BF.csv')
AL5 = read.csv ('C:/Users/a426f262/Downloads/GHT-and-COVID19-code-main/GHT-and-COVID19-code-main/data and results/data and results/GHT data/SL_SL.csv')
AL6 = read.csv ('C:/Users/a426f262/Downloads/GHT-and-COVID19-code-main/GHT-and-COVID19-code-main/data and results/data and results/GHT data/SD_SD.csv')

AL1$date = as.Date(AL1$date) #convert columns to actual dates
AL1 = AL1[AL1$date > '2020-02-01'& AL1$date < '2021-09-26',] 

AL2$date = as.Date(AL2$date) #convert columns to actual dates
AL2 = AL2[AL2$date > '2020-02-01'& AL2$date < '2021-09-26',] 

AL3$date = as.Date(AL3$date) #convert columns to actual dates
AL3 = AL3[AL3$date > '2020-02-01'& AL3$date < '2021-09-26',] 

AL4$date = as.Date(AL4$date) #convert columns to actual dates
AL4 = AL4[AL4$date > '2020-02-01'& AL4$date < '2021-09-26',] 

AL5$date = as.Date(AL5$date) #convert columns to actual dates
AL5 = AL5[AL5$date > '2020-02-01'& AL5$date < '2021-09-26',] 

AL6$date = as.Date(AL6$date) #convert columns to actual dates
AL6 = AL6[AL6$date > '2020-02-01'& AL6$date < '2021-09-26',] 

#usful words: 
AL1 = AL1[,colSums(AL1 !=0) >0] #this selects those columns that have information 
AL2 = AL2[,colSums(AL2 !=0) >0]
AL3 = AL3[,colSums(AL3 !=0) >0] 
AL4 = AL4[,colSums(AL4 !=0) >0]  
AL5 = AL5[,colSums(AL5 !=0) >0]  
AL6 = AL6[,colSums(AL6 !=0) >0]  




#important words: 

def_tms1 = AL1[,2:length(AL1)] #only terms dataset
def_tms2 = AL2[,2:length(AL2)] 
def_tms3 = AL3[,2:length(AL3)] 
def_tms4 = AL4[,2:length(AL4)] 
def_tms5 = AL5[,2:length(AL5)] 
def_tms6 = AL6[,2:length(AL6)] 

#4 predefined terms
def_tms1 <- data.frame('COVID19' = def_tms1$COVID19, 
                       'coronavirus' = def_tms1$coronavirus,
                       'coronavirus symptoms' = def_tms1$coronavirus.symptoms, 
                       'pandemic' = def_tms1$pandemic)
def_tms2 <- data.frame('COVID19' = def_tms2$COVID19, 
                       'coronavirus' = def_tms2$coronavirus,
                       'coronavirus symptoms' = def_tms2$coronavirus.symptoms, 
                       'pandemic' = def_tms2$pandemic)
def_tms3 <- data.frame('COVID19' = def_tms3$COVID19, 
                       'coronavirus' = def_tms3$coronavirus,
                       'coronavirus symptoms' = def_tms3$coronavirus.symptoms, 
                       'pandemic' = def_tms3$pandemic)
def_tms4 <- data.frame('COVID19' = def_tms4$COVID19, 
                       'coronavirus' = def_tms4$coronavirus,
                       'coronavirus symptoms' = def_tms4$coronavirus.symptoms, 
                       'pandemic' = def_tms4$pandemic)
def_tms5 <- data.frame('COVID19' = def_tms5$COVID19, 
                       'coronavirus' = def_tms5$coronavirus,
                       'coronavirus symptoms' = def_tms5$coronavirus.symptoms, 
                       'pandemic' = def_tms5$pandemic)
def_tms6 <- data.frame('COVID19' = def_tms6$COVID19, 
                       'coronavirus' = def_tms6$coronavirus,
                       'coronavirus symptoms' = def_tms6$coronavirus.symptoms, 
                       'pandemic' = def_tms6$pandemic)

median_tm1 = apply(def_tms1, 2, FUN= median) #obtaining a vector with the medians
bp1 = names(median_tm1)#names for boxplot
bp1 = bp1[order(median_tm1, decreasing = T)] #order names highest to lowest

median_tm2 = apply(def_tms2, 2, FUN= median) 
bp2 = names(median_tm2)#names for boxplot
bp2 = bp2[order(median_tm2, decreasing = T)]

median_tm3 = apply(def_tms3, 2, FUN= median) 
bp3 = names(median_tm3)#names for boxplot
bp3 = bp3[order(median_tm3, decreasing = T)] 

median_tm4 = apply(def_tms4, 2, FUN= median)
bp4 = names(median_tm4)#names for boxplot
bp4 = bp4[order(median_tm4, decreasing = T)] 

median_tm5 = apply(def_tms5, 2, FUN= median) 
bp5 = names(median_tm5)#names for boxplot
bp5 = bp5[order(median_tm5, decreasing = T)] 

median_tm6 = apply(def_tms6, 2, FUN= median) 
bp6 = names(median_tm6)#names for boxplot
bp6 = bp6[order(median_tm6, decreasing = T)] 

#reading data to process by week
AL_br1 = read.csv ('C:/Users/a426f262/Downloads/GHT-and-COVID19-code-main/GHT-and-COVID19-code-main/data and results/data and results/daily_data/Algeria.csv')
AL_br2 = read.csv ('C:/Users/a426f262/Downloads/GHT-and-COVID19-code-main/GHT-and-COVID19-code-main/data and results/data and results/daily_data/Ethiopia.csv')
AL_br3 = read.csv ('C:/Users/a426f262/Downloads/GHT-and-COVID19-code-main/GHT-and-COVID19-code-main/data and results/data and results/daily_data/Kenya.csv')
AL_br4 = read.csv ('C:/Users/a426f262/Downloads/GHT-and-COVID19-code-main/GHT-and-COVID19-code-main/data and results/data and results/daily_data/BurkinaFaso.csv')
AL_br5 = read.csv ('C:/Users/a426f262/Downloads/GHT-and-COVID19-code-main/GHT-and-COVID19-code-main/data and results/data and results/daily_data/SierraLeone.csv')
AL_br6 = read.csv ('C:/Users/a426f262/Downloads/GHT-and-COVID19-code-main/GHT-and-COVID19-code-main/data and results/data and results/daily_data/Sudan.csv')

#fix the dates so that R can work with them
AL_br1$date = gsub (AL_br1$date, pattern ='/',replacement = '-')
AL_br1$date = as.Date(AL_br1$date,format="%m-%d-%Y")

AL_br2$date = gsub (AL_br2$date, pattern ='/',replacement = '-')
AL_br2$date = as.Date(AL_br2$date,format="%m-%d-%Y")

AL_br3$date = gsub (AL_br3$date, pattern ='/',replacement = '-')
AL_br3$date = as.Date(AL_br3$date,format="%m-%d-%Y")

AL_br4$date = gsub (AL_br4$date, pattern ='/',replacement = '-')
AL_br4$date = as.Date(AL_br4$date,format="%m-%d-%Y")

AL_br5$date = gsub (AL_br5$date, pattern ='/',replacement = '-')
AL_br5$date = as.Date(AL_br5$date,format="%m-%d-%Y")

AL_br6$date = gsub (AL_br6$date, pattern ='/',replacement = '-')
AL_br6$date = as.Date(AL_br6$date,format="%m-%d-%Y")

#subset appropriate timeframe
AL_br1 = AL_br1[AL_br1$date > '2020-02-01'& AL_br1$date < '2021-09-26',]
AL_br2 = AL_br2[AL_br2$date > '2020-02-01'& AL_br2$date < '2021-09-26',]
AL_br3 = AL_br3[AL_br3$date > '2020-02-01'& AL_br3$date < '2021-09-26',]
AL_br4 = AL_br4[AL_br4$date > '2020-02-01'& AL_br4$date < '2021-09-26',]
AL_br5 = AL_br5[AL_br5$date > '2020-02-01'& AL_br5$date < '2021-09-26',]
AL_br6 = AL_br6[AL_br6$date > '2020-02-01'& AL_br6$date < '2021-09-26',]

#change name of BR1 column name
colnames(AL_br1)[colnames(AL_br1) == "date"] <- "data"
colnames(AL_br2)[colnames(AL_br2) == "date"] <- "data"
colnames(AL_br3)[colnames(AL_br3) == "date"] <- "data"
colnames(AL_br4)[colnames(AL_br4) == "date"] <- "data"
colnames(AL_br5)[colnames(AL_br5) == "date"] <- "data"
colnames(AL_br6)[colnames(AL_br6) == "date"] <- "data"

length(AL1$date) == length(AL_br1$data) #notice that the column with dates in the brazialian file is called data not date
length(AL2$date) == length(AL_br2$data)
length(AL3$date) == length(AL_br3$data)
length(AL4$date) == length(AL_br4$data)
length(AL5$date) == length(AL_br5$data)
length(AL6$date) == length(AL_br6$data)

#both dataframes have the same length, thus we can convert to weekly data
BR_comp = list() #open empty list 
pop1 = data.frame(AL_br1$pop)
for (i in seq (1,length(AL_br1$data), 7)){ #loop each 7 days till the end of the DF
  rr = AL_br1[(AL_br1$data > AL_br1$data[i] & AL_br1$data <= AL_br1$data[i+7]),] #subset DF above first row 
  cs = colSums(rr[,2:ncol(rr)]) #sum cases for this subset
  df =  t(as.data.frame (cs)) #transform in dataframe and transpose
  cs2 = cbind (data = as.character(AL_br1$data[i+7]), df) #add the name to the dataframe
  BR_comp[[length(BR_comp)+1]] = cs2 #add to the list 
}

BR_rw = ldply(BR_comp, data.frame) #transform list to dataframe
AL_br1_week = rbind (AL_br1[1,1:ncol(AL_br1)], BR_rw) #add first row previously ignored 
AL_br1_week = AL_br1_week[-(length(AL_br1_week$data)),] #eliminate last row with NA if needed
AL_br1_week$data = as.Date(AL_br1_week$data) #define first column as class dates 
#add population column, you will need to look this up for each country
AL_br1_week$pop=rep(pop1[1,"AL_br1.pop"],length(AL_br1_week$New.Cases))

BR_comp = list() #open empty list 
pop2 = data.frame(AL_br2$pop)
for (i in seq (1,length(AL_br2$data), 7)){ #loop each 7 days till the end of the DF
  rr = AL_br2[(AL_br2$data > AL_br2$data[i] & AL_br2$data <= AL_br2$data[i+7]),] #subset DF above first row 
  cs = colSums(rr[,2:ncol(rr)]) #sum cases for this subset
  df =  t(as.data.frame (cs)) #transform in dataframe and transpose
  cs2 = cbind (data = as.character(AL_br2$data[i+7]), df) #add the name to the dataframe
  BR_comp[[length(BR_comp)+1]] = cs2 #add to the list 
}

BR_rw = ldply(BR_comp, data.frame) #transform list to dataframe
AL_br2_week = rbind (AL_br2[1,1:ncol(AL_br2)], BR_rw) #add first row previously ignored 
AL_br2_week = AL_br2_week[-(length(AL_br2_week$data)),] #eliminate last row with NA if needed
AL_br2_week$data = as.Date(AL_br2_week$data) #define first column as class dates 
#add population column, you will need to look this up for each country
AL_br2_week$pop=rep(pop2[1,"AL_br2.pop"],length(AL_br2_week$New.Cases))

BR_comp = list() #open empty list 
pop3 = data.frame(AL_br3$pop)
for (i in seq (1,length(AL_br3$data), 7)){ #loop each 7 days till the end of the DF
  rr = AL_br3[(AL_br3$data > AL_br3$data[i] & AL_br3$data <= AL_br3$data[i+7]),] #subset DF above first row 
  cs = colSums(rr[,2:ncol(rr)]) #sum cases for this subset
  df =  t(as.data.frame (cs)) #transform in dataframe and transpose
  cs2 = cbind (data = as.character(AL_br3$data[i+7]), df) #add the name to the dataframe
  BR_comp[[length(BR_comp)+1]] = cs2 #add to the list 
}

BR_rw = ldply(BR_comp, data.frame) #transform list to dataframe
AL_br3_week = rbind (AL_br3[1,1:ncol(AL_br3)], BR_rw) #add first row previously ignored 
AL_br3_week = AL_br3_week[-(length(AL_br3_week$data)),] #eliminate last row with NA if needed
AL_br3_week$data = as.Date(AL_br3_week$data) #define first column as class dates 
#add population column, you will need to look this up for each country
AL_br3_week$pop=rep(pop3[1,"AL_br3.pop"],length(AL_br3_week$New.Cases))

BR_comp = list() #open empty list 
pop4 = data.frame(AL_br4$pop)
for (i in seq (1,length(AL_br4$data), 7)){ #loop each 7 days till the end of the DF
  rr = AL_br4[(AL_br4$data > AL_br4$data[i] & AL_br4$data <= AL_br4$data[i+7]),] #subset DF above first row 
  cs = colSums(rr[,2:ncol(rr)]) #sum cases for this subset
  df =  t(as.data.frame (cs)) #transform in dataframe and transpose
  cs2 = cbind (data = as.character(AL_br4$data[i+7]), df) #add the name to the dataframe
  BR_comp[[length(BR_comp)+1]] = cs2 #add to the list 
}

BR_rw = ldply(BR_comp, data.frame) #transform list to dataframe
AL_br4_week = rbind (AL_br4[1,1:ncol(AL_br4)], BR_rw) #add first row previously ignored 
AL_br4_week = AL_br4_week[-(length(AL_br4_week$data)),] #eliminate last row with NA if needed
AL_br4_week$data = as.Date(AL_br4_week$data) #define first column as class dates 
#add population column, you will need to look this up for each country
AL_br4_week$pop=rep(pop4[1,"AL_br4.pop"],length(AL_br4_week$New.Cases))

BR_comp = list() #open empty list 
pop5 = data.frame(AL_br5$pop)
for (i in seq (1,length(AL_br5$data), 7)){ #loop each 7 days till the end of the DF
  rr = AL_br5[(AL_br5$data > AL_br5$data[i] & AL_br5$data <= AL_br5$data[i+7]),] #subset DF above first row 
  cs = colSums(rr[,2:ncol(rr)]) #sum cases for this subset
  df =  t(as.data.frame (cs)) #transform in dataframe and transpose
  cs2 = cbind (data = as.character(AL_br5$data[i+7]), df) #add the name to the dataframe
  BR_comp[[length(BR_comp)+1]] = cs2 #add to the list 
}

BR_rw = ldply(BR_comp, data.frame) #transform list to dataframe
AL_br5_week = rbind (AL_br5[1,1:ncol(AL_br5)], BR_rw) #add first row previously ignored 
AL_br5_week = AL_br5_week[-(length(AL_br5_week$data)),] #eliminate last row with NA if needed
AL_br5_week$data = as.Date(AL_br5_week$data) #define first column as class dates 
#add population column, you will need to look this up for each country
AL_br5_week$pop=rep(pop5[1,"AL_br5.pop"],length(AL_br5_week$New.Cases))

BR_comp = list() #open empty list 
pop6 = data.frame(AL_br6$pop)
for (i in seq (1,length(AL_br6$data), 7)){ #loop each 7 days till the end of the DF
  rr = AL_br6[(AL_br6$data > AL_br6$data[i] & AL_br6$data <= AL_br6$data[i+7]),] #subset DF above first row 
  cs = colSums(rr[,2:ncol(rr)]) #sum cases for this subset
  df =  t(as.data.frame (cs)) #transform in dataframe and transpose
  cs2 = cbind (data = as.character(AL_br6$data[i+7]), df) #add the name to the dataframe
  BR_comp[[length(BR_comp)+1]] = cs2 #add to the list 
}

BR_rw = ldply(BR_comp, data.frame) #transform list to dataframe
AL_br6_week = rbind (AL_br6[1,1:ncol(AL_br6)], BR_rw) #add first row previously ignored 
AL_br6_week = AL_br6_week[-(length(AL_br6_week$data)),] #eliminate last row with NA if needed
AL_br6_week$data = as.Date(AL_br6_week$data) #define first column as class dates 
#add population column, you will need to look this up for each country
AL_br6_week$pop=rep(pop6[1,"AL_br6.pop"],length(AL_br6_week$New.Cases))

#convert GHT data to weekly data
AL1_comp = list() #open empty list 
for (i in seq (1,length(AL1$date), 7)){ #loop each 7 days till the end of the DF
  rr = AL1[(AL1$date > AL1$date[i] & AL1$date <= AL1$date[i+7]),] #subset DF above first row 
  cs = colSums(rr[,2:ncol(rr)]) #sum cases for this subset
  df =  t(as.data.frame (cs)) #transform in dataframe and transpose
  cs2 = cbind (data = as.character(AL1$date[i+7]), df) #add the name to the dataframe
  AL1_comp[[length(AL1_comp)+1]] = cs2 #add to the list 
}
#change name of AL2 column name
colnames(AL1)[colnames(AL1) == "date"] <- "data"

AL1_rw = ldply(AL1_comp, data.frame) #transform list to dataframe
AL1_week = rbind (AL1[1,1:ncol(AL1)], AL1_rw) #add first row previously ignored 
AL1_week = AL1_week[-(length(AL1_week$data)),] #eliminate last row with NA if needed
AL1_week$data = as.Date(AL1_week$data) #define first column as class dates 
AL1_week = data.frame(data.matrix(AL1_week))

AL2_comp = list() #open empty list 
for (i in seq (1,length(AL2$date), 7)){ #loop each 7 days till the end of the DF
  rr = AL2[(AL2$date > AL2$date[i] & AL2$date <= AL2$date[i+7]),] #subset DF above first row 
  cs = colSums(rr[,2:ncol(rr)]) #sum cases for this subset
  df =  t(as.data.frame (cs)) #transform in dataframe and transpose
  cs2 = cbind (data = as.character(AL2$date[i+7]), df) #add the name to the dataframe
  AL2_comp[[length(AL2_comp)+1]] = cs2 #add to the list 
}
#change name of AL2 column name
colnames(AL2)[colnames(AL2) == "date"] <- "data"

AL2_rw = ldply(AL2_comp, data.frame) #transform list to dataframe
AL2_week = rbind (AL2[1,1:ncol(AL2)], AL2_rw) #add first row previously ignored 
AL2_week = AL2_week[-(length(AL2_week$data)),] #eliminate last row with NA if needed
AL2_week$data = as.Date(AL2_week$data) #define first column as class dates 
AL2_week = data.frame(data.matrix(AL2_week))

AL3_comp = list() #open empty list 
for (i in seq (1,length(AL3$date), 7)){ #loop each 7 days till the end of the DF
  rr = AL3[(AL3$date > AL3$date[i] & AL3$date <= AL3$date[i+7]),] #subset DF above first row 
  cs = colSums(rr[,2:ncol(rr)]) #sum cases for this subset
  df =  t(as.data.frame (cs)) #transform in dataframe and transpose
  cs2 = cbind (data = as.character(AL3$date[i+7]), df) #add the name to the dataframe
  AL3_comp[[length(AL3_comp)+1]] = cs2 #add to the list 
}
#change name of AL2 column name
colnames(AL3)[colnames(AL3) == "date"] <- "data"

AL3_rw = ldply(AL3_comp, data.frame) #transform list to dataframe
AL3_week = rbind (AL3[1,1:ncol(AL3)], AL3_rw) #add first row previously ignored 
AL3_week = AL3_week[-(length(AL3_week$data)),] #eliminate last row with NA if needed
AL3_week$data = as.Date(AL3_week$data) #define first column as class dates 
AL3_week = data.frame(data.matrix(AL3_week))

AL4_comp = list() #open empty list 
for (i in seq (1,length(AL4$date), 7)){ #loop each 7 days till the end of the DF
  rr = AL4[(AL4$date > AL4$date[i] & AL4$date <= AL4$date[i+7]),] #subset DF above first row 
  cs = colSums(rr[,2:ncol(rr)]) #sum cases for this subset
  df =  t(as.data.frame (cs)) #transform in dataframe and transpose
  cs2 = cbind (data = as.character(AL4$date[i+7]), df) #add the name to the dataframe
  AL4_comp[[length(AL4_comp)+1]] = cs2 #add to the list 
}
#change name of AL2 column name
colnames(AL4)[colnames(AL4) == "date"] <- "data"

AL4_rw = ldply(AL4_comp, data.frame) #transform list to dataframe
AL4_week = rbind (AL4[1,1:ncol(AL4)], AL4_rw) #add first row previously ignored 
AL4_week = AL4_week[-(length(AL4_week$data)),] #eliminate last row with NA if needed
AL4_week$data = as.Date(AL4_week$data) #define first column as class dates 
AL4_week = data.frame(data.matrix(AL4_week))

AL5_comp = list() #open empty list 
for (i in seq (1,length(AL5$date), 7)){ #loop each 7 days till the end of the DF
  rr = AL5[(AL5$date > AL5$date[i] & AL5$date <= AL5$date[i+7]),] #subset DF above first row 
  cs = colSums(rr[,2:ncol(rr)]) #sum cases for this subset
  df =  t(as.data.frame (cs)) #transform in dataframe and transpose
  cs2 = cbind (data = as.character(AL5$date[i+7]), df) #add the name to the dataframe
  AL5_comp[[length(AL5_comp)+1]] = cs2 #add to the list 
}
#change name of AL2 column name
colnames(AL5)[colnames(AL5) == "date"] <- "data"

AL5_rw = ldply(AL5_comp, data.frame) #transform list to dataframe
AL5_week = rbind (AL5[1,1:ncol(AL5)], AL5_rw) #add first row previously ignored 
AL5_week = AL5_week[-(length(AL5_week$data)),] #eliminate last row with NA if needed
AL5_week$data = as.Date(AL5_week$data) #define first column as class dates 
AL5_week = data.frame(data.matrix(AL5_week))

AL6_comp = list() #open empty list 
for (i in seq (1,length(AL6$date), 7)){ #loop each 7 days till the end of the DF
  rr = AL6[(AL6$date > AL6$date[i] & AL6$date <= AL6$date[i+7]),] #subset DF above first row 
  cs = colSums(rr[,2:ncol(rr)]) #sum cases for this subset
  df =  t(as.data.frame (cs)) #transform in dataframe and transpose
  cs2 = cbind (data = as.character(AL6$date[i+7]), df) #add the name to the dataframe
  AL6_comp[[length(AL6_comp)+1]] = cs2 #add to the list 
}
#change name of AL2 column name
colnames(AL6)[colnames(AL6) == "date"] <- "data"

AL6_rw = ldply(AL6_comp, data.frame) #transform list to dataframe
AL6_week = rbind (AL6[1,1:ncol(AL6)], AL6_rw) #add first row previously ignored 
AL6_week = AL6_week[-(length(AL6_week$data)),] #eliminate last row with NA if needed
AL6_week$data = as.Date(AL6_week$data) #define first column as class dates 
AL6_week = data.frame(data.matrix(AL6_week))
#defining date column 
AL_br1_week$data = as.Date (AL_br1_week$data)
AL_br2_week$data = as.Date (AL_br2_week$data)
AL_br3_week$data = as.Date (AL_br3_week$data)
AL_br4_week$data = as.Date (AL_br4_week$data)
AL_br5_week$data = as.Date (AL_br5_week$data)
AL_br6_week$data = as.Date (AL_br6_week$data)

#linear regresion

#Objects with information of the week of the first case 
# ot1 = read.csv ('/Tanzania.csv')
# ot1 <- data.frame('date' = ot1$date,
#                   'Cumulative Cases' = ot1$Cumulative.Cases,
#                   'New Cases' = ot1$New.Cases)
# ot1$date = gsub (ot1$date, pattern ='/',replacement = '-')
# ot1$date = as.Date(ot1$date,format="%m-%d-%Y")
# ot1$date = as.Date(ot1$date) #defining as dates
# 
# f_cc1 = ot1$New.Cases[ot1$New.Cases>0][1] #number of first cases in the original state database
# f_c1 = AL_br1$New.Cases[AL_br1$New.Cases>0][1] #number of first cases in the weekly state database
# 
# ff_1 = as.Date(ot1[which(ot1$New.Cases == f_cc1)[1], 1]) #obtain the date through index and subsetting table 1, 8 represents column with dates in this table
# ff__1 = as.Date(AL_br1[which(AL_br1$New.Cases == f_c1)[1], 1]) #obtain the date through index and subsetting table 2, 4 represents column with dates in this table
# #
# ot2 = read.csv ('/Tunisia.csv')
# ot2 <- data.frame('date' = ot2$date,
#                   'Cumulative Cases' = ot2$Cumulative.Cases,
#                   'New Cases' = ot2$New.Cases)
# ot2$date = gsub (ot2$date, pattern ='/',replacement = '-')
# ot2$date = as.Date(ot2$date,format="%m-%d-%Y")
# ot2$date = as.Date(ot2$date) #defining as dates
# 
# f_cc2 = ot2$New.Cases[ot2$New.Cases>0][1] #number of first cases in the original state database
# f_c2 = AL_br2$New.Cases[AL_br2$New.Cases>0][1] #number of first cases in the weekly state database
# 
# ff_2 = as.Date(ot2[which(ot2$New.Cases == f_cc2)[1], 1]) #obtain the date through index and subsetting table 1, 8 represents column with dates in this table
# ff__2 = as.Date(AL_br2[which(AL_br2$New.Cases == f_c2)[1], 1]) #obtain the date through index and subsetting table 2, 4 represents column with dates in this table
# #
# ot3 = read.csv ('/Burkina Faso.csv')
# ot3 <- data.frame('date' = ot3$date,
#                   'Cumulative Cases' = ot3$Cumulative.Cases,
#                   'New Cases' = ot3$New.Cases)
# #some of the dataframes already have proper dates, and re-formatting will cause errors
# # ot3$date = gsub (ot3$date, pattern ='/',replacement = '-')
# # ot3$date = as.Date(ot3$date,format="%m-%d-%Y")
# # ot3$date = as.Date(ot3$date) #defining as dates
# 
# f_cc3 = ot3$New.Cases[ot3$New.Cases>0][1] #number of first cases in the original state database
# f_c3 = AL_br3$New.Cases[AL_br3$New.Cases>0][1] #number of first cases in the weekly state database
# 
# ff_3 = as.Date(ot3[which(ot3$New.Cases == f_cc3)[1], 1]) #obtain the date through index and subsetting table 1, 8 represents column with dates in this table
# ff__3 = as.Date(AL_br3[which(AL_br3$New.Cases == f_c3)[1], 1]) #obtain the date through index and subsetting table 2, 4 represents column with dates in this table
# #
# ot4 = read.csv ('/Seychelles.csv')
# ot4 <- data.frame('date' = ot4$date,
#                   'Cumulative Cases' = ot4$Cumulative.Cases,
#                   'New Cases' = ot4$New.Cases)
# ot4$date = gsub (ot4$date, pattern ='/',replacement = '-')
# ot4$date = as.Date(ot4$date,format="%m-%d-%Y")
# ot4$date = as.Date(ot4$date) #defining as dates
# 
# f_cc4 = ot4$New.Cases[ot4$New.Cases>0][1] #number of first cases in the original state database
# f_c4 = AL_br4$New.Cases[AL_br4$New.Cases>0][1] #number of first cases in the weekly state database
# 
# ff_4 = as.Date(ot1[which(ot1$New.Cases == f_cc4)[1], 1]) #obtain the date through index and subsetting table 1, 8 represents column with dates in this table
# ff__4 = as.Date(AL_br1[which(AL_br1$New.Cases == f_c4)[1], 1]) #obtain the date through index and subsetting table 2, 4 represents column with dates in this table
# #
# ot5 = read.csv ('/Benin.csv')
# ot5 <- data.frame('date' = ot5$date,
#                   'Cumulative Cases' = ot5$Cumulative.Cases,
#                   'New Cases' = ot5$New.Cases)
# ot5$date = gsub (ot5$date, pattern ='/',replacement = '-')
# ot5$date = as.Date(ot5$date,format="%m-%d-%Y")
# ot5$date = as.Date(ot5$date) #defining as dates
# 
# f_cc5 = ot5$New.Cases[ot5$New.Cases>0][1] #number of first cases in the original state database
# f_c5 = AL_br5$New.Cases[AL_br5$New.Cases>0][1] #number of first cases in the weekly state database
# 
# ff_5 = as.Date(ot5[which(ot5$New.Cases == f_cc5)[1], 1]) #obtain the date through index and subsetting table 1, 8 represents column with dates in this table
# ff__5 = as.Date(AL_br5[which(AL_br5$New.Cases == f_c5)[1], 1]) #obtain the date through index and subsetting table 2, 4 represents column with dates in this table
# #
# ot6 = read.csv ('/Namibia.csv')
# ot6 <- data.frame('date' = ot6$date,
#                   'Cumulative Cases' = ot6$Cumulative.Cases,
#                   'New Cases' = ot6$New.Cases)
# ot6$date = gsub (ot6$date, pattern ='/',replacement = '-')
# ot6$date = as.Date(ot6$date,format="%m-%d-%Y")
# ot6$date = as.Date(ot6$date) #defining as dates
# 
# f_cc6 = ot6$New.Cases[ot6$New.Cases>0][1] #number of first cases in the original state database
# f_c6 = AL_br6$New.Cases[AL_br6$New.Cases>0][1] #number of first cases in the weekly state database
# 
# ff_6 = as.Date(ot1[which(ot6$New.Cases == f_cc6)[1], 1]) #obtain the date through index and subsetting table 1, 8 represents column with dates in this table
# ff__6 = as.Date(AL_br6[which(AL_br6$New.Cases == f_c6)[1], 1]) #obtain the date through index and subsetting table 2, 4 represents column with dates in this table
# #
#calculate incidence per state adding a new column to the brazilian datafram: inci: 
AL_br1_week$inci = as.numeric(AL_br1_week$New.Cases)/AL_br1_week$pop
AL_br2_week$inci = as.numeric(AL_br2_week$New.Cases)/AL_br2_week$pop
AL_br3_week$inci = as.numeric(AL_br3_week$New.Cases)/AL_br3_week$pop
AL_br4_week$inci = as.numeric(AL_br4_week$New.Cases)/AL_br4_week$pop
AL_br5_week$inci = as.numeric(AL_br5_week$New.Cases)/AL_br5_week$pop
AL_br6_week$inci = as.numeric(AL_br6_week$New.Cases)/AL_br6_week$pop

bt1 = paste('AL1_week', '$', bp1 , sep = '') #VECTOR SUBSETTING THE COLUMNS ACCORDING TO THE MENTIONED WORDS
bt2 = paste('AL2_week', '$', bp2 , sep = '')
bt3 = paste('AL3_week', '$', bp3 , sep = '')
bt4 = paste('AL4_week', '$', bp4 , sep = '') 
bt5 = paste('AL5_week', '$', bp5 , sep = '') 
bt6 = paste('AL6_week', '$', bp6 , sep = '') 


AL1_form1 = formula(c(paste ('as.matrix(AL_br1_week$inci)~'), 
                      paste(as.matrix(bt1), collapse = ' + '))) #formula for the regression
AL1_form2 = formula(c(paste ('as.matrix(AL_br2_week$inci)~'), 
                      paste(as.matrix(bt2), collapse = ' + '))) 
AL1_form3 = formula(c(paste ('as.matrix(AL_br3_week$inci)~'), 
                      paste(as.matrix(bt3), collapse = ' + '))) 
AL1_form4 = formula(c(paste ('as.matrix(AL_br4_week$inci)~'), 
                      paste(as.matrix(bt4), collapse = ' + '))) 
AL1_form5 = formula(c(paste ('as.matrix(AL_br5_week$inci)~'), 
                      paste(as.matrix(bt5), collapse = ' + '))) 
AL1_form6 = formula(c(paste ('as.matrix(AL_br6_week$inci)~'), 
                      paste(as.matrix(bt6), collapse = ' + '))) 

AL1_model1 = lm(AL1_form1) #regression 
AL1_model2 = lm(AL1_form2) #regression 
AL1_model3 = lm(AL1_form3) #regression 
AL1_model4 = lm(AL1_form4) #regression 
AL1_model5 = lm(AL1_form5) #regression 
AL1_model6 = lm(AL1_form6) #regression 

AL1_rq1 = summary(AL1_model1)$adj.r.squared #collect adj. r squared
AL1_rq2 = summary(AL1_model2)$adj.r.squared 
AL1_rq3 = summary(AL1_model3)$adj.r.squared 
AL1_rq4 = summary(AL1_model4)$adj.r.squared 
AL1_rq5 = summary(AL1_model5)$adj.r.squared 
AL1_rq6 = summary(AL1_model6)$adj.r.squared 

#set the working directory so that you know where your figures go after being generated
setwd('')

#plot all 6 countries in one pane
tiff("test.png", units="in", width=10, height=5, res=300)
par(mfrow=c(2,3))

#plot incidence
plot (AL_br1_week$inci, main = paste('Algeria', '\n\ Adj. R squared =', round(AL1_rq1,4)), 
      ylab = 'Weekly incidence', xlab = '', xaxt ='n',
      type = 'l', pch = 19, cex = 0.3, cex.axis = 1.3, cex.main = 1.5, cex.lab = 1.4) 
#regression line 
lines (predict (AL1_model1), col = 'blue', type ='b', pch = 19, cex = 0.3) 
#x-axis
# axis (1, at=c(1,6,10,15,19), 
#       labels = c('Feb', 'March', 'April', 'May', 'June'), cex.axis = 1.3)

# text (6, quantile(AL_br1$inci, 0.95),
#       labels = paste ('First case = ', '\n\ ', ff_1, sep = ''), 
#       cex = 0.8, pos = '1', col= 'red', srt = 0)

#plot incidence
plot (AL_br2_week$inci, main = paste('Ethiopia', '\n\ Adj. R squared =', round(AL1_rq2,4)), 
      ylab = 'Weekly incidence', xlab = '', xaxt ='n',
      type = 'l', pch = 19, cex = 0.3, cex.axis = 1.3, cex.main = 1.5, cex.lab = 1.4) 
#regression line 
lines (predict (AL1_model2), col = 'blue', type ='b', pch = 19, cex = 0.3) 
#x-axis
# axis (1, at=c(1,6,10,15,19), 
#       labels = c('Feb', 'March', 'April', 'May', 'June'), cex.axis = 1.3)

# text (20, quantile(AL_br2$inci, 0.95),
#       labels = paste ('First case = ', '\n\ ', ff_2, sep = ''), 
#       cex = 0.8, pos = '1', col= 'red', srt = 0)

#plot incidence
plot (AL_br3_week$inci, main = paste('Kenya', '\n\ Adj. R squared =', round(AL1_rq3,4)), 
      ylab = 'Weekly incidence', xlab = '', xaxt ='n',
      type = 'l', pch = 19, cex = 0.3, cex.axis = 1.3, cex.main = 1.5, cex.lab = 1.4) 
#regression line 
lines (predict (AL1_model3), col = 'blue', type ='b', pch = 19, cex = 0.3) 
#x-axis
# axis (1, at=c(1,6,10,15,19), 
#       labels = c('Feb', 'March', 'April', 'May', 'June'), cex.axis = 1.3)

# text (20, quantile(AL_br3$inci, 0.95),
#       labels = paste ('First case = ', '\n\ ', ff__3, sep = ''), 
#       cex = 0.8, pos = '1', col= 'red', srt = 0)

#plot incidence
plot (AL_br4_week$inci, main = paste('Burkina Faso', '\n\ Adj. R squared =', round(AL1_rq4,4)), 
      ylab = 'Weekly incidence', xlab = '', xaxt ='n',
      type = 'l', pch = 19, cex = 0.3, cex.axis = 1.3, cex.main = 1.5, cex.lab = 1.4) 
#regression line 
lines (predict (AL1_model4), col = 'blue', type ='b', pch = 19, cex = 0.3) 
#x-axis
# axis (1, at=c(1,6,10,15,19), 
#       labels = c('Feb', 'March', 'April', 'May', 'June'), cex.axis = 1.3)

# text (7, quantile(AL_br4$inci, 0.95),
#       labels = paste ('First case = ', '\n\ ', ff_4, sep = ''), 
#       cex = 0.8, pos = '3', col= 'red', srt = 0)

#plot incidence
plot (AL_br5_week$inci, main = paste('Sierra Leone', '\n\ Adj. R squared =', round(AL1_rq5,4)), 
      ylab = 'Weekly incidence', xlab = '', xaxt ='n',
      type = 'l', pch = 19, cex = 0.3, cex.axis = 1.3, cex.main = 1.5, cex.lab = 1.4) 
#regression line 
lines (predict (AL1_model5), col = 'blue', type ='b', pch = 19, cex = 0.3) 
#x-axis
# axis (1, at=c(1,6,10,15,19), 
#       labels = c('Feb', 'March', 'April', 'May', 'June'), cex.axis = 1.3)

# text (7, quantile(AL_br5$inci, 0.95),
#       labels = paste ('First case = ', '\n\ ', ff__5, sep = ''), 
#       cex = 0.8, pos = '1', col= 'red', srt = 0)

#plot incidence
plot (AL_br6_week$inci, main = paste('Sudan', '\n\ Adj. R squared =', round(AL1_rq6,4)), 
      ylab = 'Weekly incidence', xlab = '', xaxt ='n',
      type = 'l', pch = 19, cex = 0.3, cex.axis = 1.3, cex.main = 1.5, cex.lab = 1.4) 
#regression line 
lines (predict (AL1_model6), col = 'blue', type ='b', pch = 19, cex = 0.3) 
#x-axis
# axis (1, at=c(1,6,10,15,19), 
#       labels = c('Feb', 'March', 'April', 'May', 'June'), cex.axis = 1.3)

# text (7, quantile(AL_br6$inci, 0.95),
#       labels = paste ('First case = ', '\n\ ', ff_6, sep = ''), 
#       cex = 0.8, pos = '1', col= 'red', srt = 0)
dev.off()


